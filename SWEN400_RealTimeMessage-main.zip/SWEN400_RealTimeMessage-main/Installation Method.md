# Installation Methods

### This is the installation method for a client using our system as a seperate entity adding onto their current web bases system. 

1. Clone the following repository for our current system 
```
git@github.com:sethers-uindy/SWEN400_RealTimeMessage.git 

or for production

new GitHub repository which only includes files for the system, non-docker.
```

2. Secondly, add the following code to the page in which you want to add the button to take you to our system. 
```
HTML and Javascript code 
```

3. Thirdly, add the 'app' folder within your file system, making sure the routing works in conjunction with your current systems layout including access to your MySQL database. 

### Installation Method for embedding the Real Time Chat system within your current system




