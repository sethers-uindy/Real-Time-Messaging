# Docker Compose Nodejs and MySQL example

## Run the System
We can easily run the whole with only a single command:
```bash
docker-compose up
```

