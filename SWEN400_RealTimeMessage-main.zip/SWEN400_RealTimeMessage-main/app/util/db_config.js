
const dbConfig = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "123456",
  DB: "open_souce_chat"
};

export default dbConfig;